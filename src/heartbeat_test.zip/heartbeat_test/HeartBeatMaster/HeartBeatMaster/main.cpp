//
//  main.cpp
//  HeartBeatMaster
//
//  Created by Marcel Ochsendorf on 20.09.17.
//  Copyright © 2017 Marcel Ochsendorf. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
